from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser, Prodotto, Prenotazione


# Customizzazione per CustomUser con campo "role"
class CustomUserAdmin(UserAdmin):
    model = CustomUser
    fieldsets = UserAdmin.fieldsets + (
        ("Ruolo", {'fields': ('role',)}),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        ("Ruolo", {'fields': ('role',)}),
    )

# Registrazioni nel pannello admin
admin.site.register(CustomUser, CustomUserAdmin)
admin.site.register(Prodotto)
admin.site.register(Prenotazione)
