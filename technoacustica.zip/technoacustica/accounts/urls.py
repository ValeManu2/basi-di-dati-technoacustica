from django.urls import path
from . import views

app_name = 'accounts'

urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.register_view, name='register'),
    path('verify-otp/', views.verify_otp_view, name='verify_otp'),
    path('prenotazioni-medico/', views.medici_prenotazioni_view, name='prenotazioni_medico'),
    path('test-csrf/', views.test_csrf_view, name='test_csrf'),

    # API
    path('api/visite/', views.visite_api, name='visite_api'),
    path('api/prenota/', views.crea_prenotazione_api, name='crea_prenotazione_api'),
]
