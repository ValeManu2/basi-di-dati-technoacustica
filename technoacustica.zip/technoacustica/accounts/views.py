from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.http import JsonResponse, HttpResponseBadRequest
from django.conf import settings
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_protect, csrf_exempt
from django import forms
import json

from .forms import UserRegisterForm
from .models import CustomUser, Prodotto, Prenotazione

# Form login personalizzato
class LoginForm(forms.Form):
    username = forms.CharField(label='Username', max_length=150)
    password = forms.CharField(label='Password', widget=forms.PasswordInput)

# Registrazione
def register_view(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.first_name = form.cleaned_data['first_name']
            user.last_name = form.cleaned_data['last_name']
            user.role = form.cleaned_data['role']
            user.is_active = False
            user.save()

            # genera e invia OTP
            user.generate_otp()
            send_mail(
                'Codice OTP - Verifica Account',
                f'Il tuo codice OTP è: {user.otp_code}',
                settings.EMAIL_HOST_USER,
                [user.email],
                fail_silently=False,
            )

            request.session['otp_user_id'] = user.id
            return redirect('accounts:verify_otp')
    else:
        form = UserRegisterForm()
    return render(request, 'registration/register.html', {'form': form})

# Verifica OTP
def verify_otp_view(request):
    user_id = request.session.get('otp_user_id')
    if not user_id:
        return redirect('accounts:login')

    user = get_object_or_404(CustomUser, id=user_id)

    if request.method == 'POST':
        code = request.POST.get('otp')
        if code == user.otp_code:
            user.is_active = True
            user.is_verified = True
            user.otp_code = ''
            user.save()
            login(request, user)
            return redirect('core:home')
        else:
            messages.error(request, 'Codice OTP errato.')
    return render(request, 'registration/verify_otp.html')

# Login
@csrf_protect
def login_view(request):
    form = LoginForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                if user.is_active and user.is_verified:
                    login(request, user)
                    return redirect('core:home')
                else:
                    messages.error(request, 'Account non verificato.')
            else:
                messages.error(request, 'Credenziali non valide.')
    return render(request, 'accounts/login.html', {'form': form})

# Logout
@login_required
def logout_view(request):
    logout(request)
    return redirect('accounts:login')

# Home (utenti loggati)
@login_required
def home_view(request):
    medici = CustomUser.objects.filter(role='medico')
    prodotti = Prodotto.objects.all()
    return render(request, 'home.html', {'medici': medici, 'prodotti': prodotti})

# API: eventi calendario
@login_required
def visite_api(request):
    if request.user.role != 'paziente':
        return JsonResponse([], safe=False)

    qs = Prenotazione.objects.all()
    events = [
        {
            'title': vis.paziente.username,
            'start': vis.data_visita.isoformat()
        }
        for vis in qs
    ]
    return JsonResponse(events, safe=False)

# API: crea prenotazione
@csrf_exempt
@require_POST
@login_required
def crea_prenotazione_api(request):
    if request.user.role != 'paziente':
        return HttpResponseBadRequest()
    data = json.loads(request.body)
    medico = get_object_or_404(CustomUser, pk=data['medico_id'], role='medico')
    Prenotazione.objects.create(
        paziente=request.user,
        medico=medico,
        data_visita=data['start']
    )
    return JsonResponse({'status': 'ok'})

# Vista per medici
@login_required
def medici_prenotazioni_view(request):
    if request.user.role != 'medico':
        return redirect('core:home')
    visite = Prenotazione.objects.filter(medico=request.user).order_by('data_visita')
    return render(request, 'prenotazioni_medico.html', {'visite': visite})

# Test CSRF (debug)
@csrf_protect
def test_csrf_view(request):
    if request.method == 'POST':
        return render(request, 'accounts/test_csrf_ok.html')
    return render(request, 'accounts/test_csrf_form.html')
