from django.db import models
from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.core.mail import send_mail
import random


class CustomUser(AbstractUser):
    ROLE_CHOICES = (
        ('paziente', 'Paziente'),
        ('medico', 'Medico'),
    )
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='paziente')
    is_verified = models.BooleanField(default=False)
    otp_code = models.CharField(max_length=6, blank=True, null=True)

    def __str__(self):
        return self.username

    def generate_otp(self):
        otp = str(random.randint(100000, 999999))
        self.otp_code = otp
        self.save()

        send_mail(
            subject='Codice OTP di verifica',
            message=f'Ciao {self.username}, il tuo codice OTP è: {otp}',
            from_email='noreply@tecnoacustica.local',
            recipient_list=[self.email],
            fail_silently=False,
        )


class Prodotto(models.Model):
    nome = models.CharField(max_length=100)
    descrizione = models.TextField(blank=True)
    prezzo = models.DecimalField(max_digits=7, decimal_places=2)

    def __str__(self):
        return self.nome


class Prenotazione(models.Model):
    paziente = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='prenotazioni')
    medico = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='visite')
    data_visita = models.DateTimeField()

    def __str__(self):
        return f"{self.paziente.username} - {self.medico.username} ({self.data_visita})"



def home_view(request):
    prodotti = Prodotto.objects.all()
    medici = CustomUser.objects.filter(role='medico')
    return render(request, 'home.html', {
        'prodotti': prodotti,
        'medici': medici,
    })