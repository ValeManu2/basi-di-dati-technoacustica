from django.urls import path
from .views import booking_form_view, create_booking_view  # importa solo questa view per ora
from . import views


app_name = 'booking'

urlpatterns = [
    path('form/', booking_form_view, name='booking_form'),
    path('create/', views.create_booking_view, name='create_booking'),
]
