from django.shortcuts import render, redirect
from .models import Booking
from django.contrib import messages

def booking_form_view(request):
    date = request.GET.get('date', '')
    medico_id = request.GET.get('medico_id', '')
    return render(request, 'booking/booking_form.html', {
        'selected_date': date,
        'selected_medico_id': medico_id,
    })

def create_booking_view(request):
    if request.method == 'POST':
        customer = request.POST.get('customer', '').strip()
        phone = request.POST.get('phone', '').strip()
        email = request.POST.get('email', '').strip()
        visit_type = request.POST.get('visit_type', '').strip()
        date_str = request.POST.get('date', '').strip()

        if not all([customer, phone, email, visit_type, date_str]):
            messages.error(request, "Tutti i campi sono obbligatori.")
            return redirect('booking:booking_form')

        from django.utils.dateparse import parse_datetime
        date = parse_datetime(date_str)
        if date is None:
            messages.error(request, "Formato data non valido.")
            return redirect('booking:booking_form')

        booking = Booking(
            customer=customer,
            phone=phone,
            email=email,
            visit_type=visit_type,
            date=date,
        )
        booking.save()

        return render(request, 'booking/booking_success.html', {'booking': booking})

    return redirect('booking:booking_form')
