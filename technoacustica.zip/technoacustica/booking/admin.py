from django.contrib import admin
from .models import Booking, Ricetta

@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('customer', 'visit_type', 'date')
    list_filter  = ('visit_type',)
    search_fields = ('customer', 'email')

@admin.register(Ricetta)
class RicettaAdmin(admin.ModelAdmin):
    list_display = ('pk', 'booking', 'created_at')
    list_filter  = ('created_at',)
    search_fields = ('booking__customer',)
