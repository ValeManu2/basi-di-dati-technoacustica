from django.db import models
from django.utils import timezone

class Booking(models.Model):
    customer   = models.CharField("Cliente", max_length=100)
    phone      = models.CharField("Telefono", max_length=20)
    email      = models.EmailField("Email")
    visit_type = models.CharField("Tipo visita", max_length=50)
    date       = models.DateTimeField("Data e ora")

    def __str__(self):
        return f"{self.customer} – {self.date:%Y-%m-%d %H:%M}"
    

class Ricetta(models.Model):
    booking = models.ForeignKey(
        Booking,
        on_delete=models.CASCADE,
        null=True,    # ora la FK può restare vuota sulle vecchie righe
        blank=True
    )
    prescription = models.TextField("Farmaci prescritti")
    created_at   = models.DateTimeField(
        default=timezone.now,   # popolerà le righe esistenti con `now()`
    )
