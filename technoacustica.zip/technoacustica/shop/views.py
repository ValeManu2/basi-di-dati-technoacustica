from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.conf import settings

from .models import Prodotto

CART_SESSION_ID = 'cart'


def get_cart(request):
    return request.session.get(CART_SESSION_ID, {})


def save_cart(request, cart):
    request.session[CART_SESSION_ID] = cart
    request.session.modified = True


def add_to_cart(request, product_id):
    """Aggiunge un prodotto al carrello in sessione"""
    prodotto = get_object_or_404(Prodotto, pk=product_id)
    cart = get_cart(request)
    prod_id_str = str(prodotto.id)

    # Incrementa quantità
    if prod_id_str in cart:
        cart[prod_id_str] += 1
    else:
        cart[prod_id_str] = 1

    save_cart(request, cart)
    messages.success(request, f"{prodotto.nome} aggiunto al carrello.")
    # Redirect alla pagina precedente, se presente
    return redirect(request.META.get('HTTP_REFERER', 'home'))


def remove_from_cart(request, product_id):
    """Rimuove un prodotto dal carrello in sessione"""
    cart = get_cart(request)
    prod_id_str = str(product_id)

    if prod_id_str in cart:
        del cart[prod_id_str]
        save_cart(request, cart)
        messages.success(request, "Prodotto rimosso dal carrello.")
    else:
        messages.error(request, "Prodotto non trovato nel carrello.")

    return redirect('shop:cart_detail')


def cart_detail(request):
    """Mostra il contenuto del carrello"""
    cart = get_cart(request)
    prodotti = []
    total = 0

    for prod_id_str, qty in cart.items():
        prodotto = get_object_or_404(Prodotto, pk=int(prod_id_str))
        line_total = prodotto.prezzo * qty
        total += line_total
        prodotti.append({
            'prodotto': prodotto,
            'quantita': qty,
            'line_total': line_total,
        })

    context = {
        'prodotti_carrello': prodotti,
        'total': total,
    }
    return render(request, 'shop/cart_detail.html', context)
