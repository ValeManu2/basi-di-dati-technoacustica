from django.contrib import admin
from .models import Prodotto, Ordine, DettaglioOrdine

admin.site.register(Prodotto)
admin.site.register(Ordine)
admin.site.register(DettaglioOrdine)
