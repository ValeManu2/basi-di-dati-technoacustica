from django.db import models

class Prodotto(models.Model):
    nome = models.CharField(max_length=100)
    descrizione = models.TextField(blank=True)  # <-- campo aggiunto
    prezzo = models.DecimalField(max_digits=8, decimal_places=2)

    def __str__(self):
        return self.nome

class Ordine(models.Model):
    data = models.DateTimeField(auto_now_add=True)
    cliente = models.CharField(max_length=100)
    totale = models.DecimalField(max_digits=8, decimal_places=2)

    def __str__(self):
        return f"Ordine#{self.pk} – {self.cliente}"

class DettaglioOrdine(models.Model):
    ordine = models.ForeignKey(Ordine, on_delete=models.CASCADE, related_name='dettagli')
    prodotto = models.ForeignKey(Prodotto, on_delete=models.CASCADE)
    quantita = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.prodotto.nome} x{self.quantita}"
