from django.db import models

# Create your models here.


class Device(models.Model):
    name        = models.CharField("Modello", max_length=100)
    description = models.TextField("Descrizione", blank=True)
    image       = models.ImageField("Foto", upload_to='devices/', blank=True)
    created_at  = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class RepairRequest(models.Model):
    device       = models.ForeignKey(Device, on_delete=models.CASCADE, verbose_name="Apparecchio")
    customer     = models.CharField("Cliente", max_length=100)
    phone        = models.CharField("Telefono", max_length=20)
    issue        = models.TextField("Problema segnalato")
    created_at   = models.DateTimeField(auto_now_add=True)
    STATUS_CHOICES = [
        ('pending', 'In attesa'),
        ('in_progress', 'In lavorazione'),
        ('done', 'Concluso'),
    ]
    status       = models.CharField("Stato", max_length=12, choices=STATUS_CHOICES, default='pending')

    def __str__(self):
        return f"{self.device} – {self.customer}"
