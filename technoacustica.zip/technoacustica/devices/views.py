# devices/views.py
from django.views.generic import ListView, DetailView, CreateView
from django.urls import reverse_lazy
from .models import Device, RepairRequest

class DeviceListView(ListView):
    model = Device
    template_name = 'devices/device_list.html'
    context_object_name = 'devices'

class DeviceDetailView(DetailView):
    model = Device
    template_name = 'devices/device_detail.html'
    context_object_name = 'device'

class RepairRequestCreateView(CreateView):
    model = RepairRequest
    fields = ['device', 'customer', 'phone', 'issue']
    template_name = 'devices/repair_form.html'
    success_url = reverse_lazy('device-list')
