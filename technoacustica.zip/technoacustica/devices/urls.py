# devices/urls.py
from django.urls import path
from .views import (
    DeviceListView,
    DeviceDetailView,
    RepairRequestCreateView
)

urlpatterns = [
    path('',               DeviceListView.as_view(),    name='device-list'),
    path('<int:pk>/',      DeviceDetailView.as_view(),  name='device-detail'),
    path('<int:pk>/ripara/', RepairRequestCreateView.as_view(), name='repair-create'),
]
