from django.contrib import admin
from .models import Utente, Medico, Paziente

admin.site.register(Utente)
admin.site.register(Medico)
admin.site.register(Paziente)
