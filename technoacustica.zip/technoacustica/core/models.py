# core/models.py
from django.db import models

class Utente(models.Model):
    ROLE_CHOICES = [
        ('medico', 'Medico'),
        ('paziente', 'Paziente'),
    ]
    id        = models.AutoField(primary_key=True)
    nome      = models.CharField("Nome",    max_length=100)
    cognome   = models.CharField("Cognome", max_length=100)
    email     = models.EmailField("Email",   unique=True)
    password  = models.CharField("Password",max_length=128)
    telefono  = models.CharField("Telefono",max_length=20)
    ruolo     = models.CharField("Ruolo",   max_length=10, choices=ROLE_CHOICES)

    def __str__(self):
        return f"{self.nome} {self.cognome} ({self.ruolo})"


class Medico(models.Model):
    # PK è la stessa FK verso Utente
    utente           = models.OneToOneField(
        Utente,
        on_delete=models.CASCADE,
        primary_key=True,
        verbose_name="Utente/Medico"
    )
    specializzazione = models.CharField("Specializzazione", max_length=200)
    telefono         = models.CharField("Telefono studio",   max_length=20)

    def __str__(self):
        return f"Dott. {self.utente.cognome} – {self.specializzazione}"


class Paziente(models.Model):
    utente       = models.OneToOneField(
        Utente,
        on_delete=models.CASCADE,
        primary_key=True,
        verbose_name="Utente/Paziente"
    )
    indirizzo    = models.CharField("Indirizzo",       max_length=200)
    data_nascita = models.DateField("Data di nascita")
    telefono     = models.CharField("Telefono",        max_length=20)

    def __str__(self):
        return f"{self.utente.nome} {self.utente.cognome}"
