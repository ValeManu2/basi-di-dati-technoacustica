from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from core.views import HomeView


urlpatterns = [
    path('admin/', admin.site.urls),

    path('', HomeView.as_view(), name='home'),

    # Core (home, calendario, ecc.)
    path('', include(('core.urls', 'core'), namespace='core')),

    # Devices
    path('devices/', include(('devices.urls', 'devices'), namespace='devices')),

    # Shop (catalogo e carrello)
    path('shop/', include(('shop.urls', 'shop'), namespace='shop')),

    # Prenotazioni (booking)
    path('booking/', include(('booking.urls', 'booking'), namespace='booking')),

    # Accounts (login, logout, registrazione, home)
    path('accounts/', include(('accounts.urls', 'accounts'), namespace='accounts')),

    # Password reset views (built-in)
    path('accounts/password_reset/', auth_views.PasswordResetView.as_view(), name='password_reset'),
    path('accounts/password_reset/done/', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
    path('accounts/reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('accounts/reset/done/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete'),

    
]
